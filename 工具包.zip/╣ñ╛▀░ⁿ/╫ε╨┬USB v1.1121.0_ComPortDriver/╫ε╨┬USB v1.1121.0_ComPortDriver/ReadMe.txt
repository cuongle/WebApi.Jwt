ReadMe.txt

	This application supports to install a com port driver, run driverinstaller.exe to complete the installation. The com port driver including a com port binary file, a co installer file and an INF file. 

[Support OS]
WinXP , Win2000 , Vista 32, Vista 64, Win7 32 , Win7 64.

[Support Device ID]
USB\VID_0E8D&PID_0003
USB\VID_0E8D&PID_0023&MI_00
USB\VID_0E8D&PID_0023&MI_02
USB\VID_0E8D&PID_0023&MI_03
USB\VID_0E8D&PID_0043&MI_00
USB\VID_0E8D&PID_0043&MI_02
USB\VID_0E8d&PID_00A0
USB\VID_0E8d&PID_00A1&MI_01
USB\VID_0E8d&PID_00A1&MI_02
USB\VID_0E8d&PID_00A2&MI_01


[Note]
1. You must make sure that device is one of the support device ID��
2. If you manually install a driver in before, uninstall the driver ,plug out and plug in device to make the newest driver to be installed after running driverinstaller.exe.


[v1.1117.0]
1. Remove USB\VID_0E8d&PID_00A1&MI_00 and USB\VID_0E8d&PID_00A2&MI_00 

[v1.1119.0]
1.Bugfix
	Resolved a bug which is lost data during speech
	Modify the name string


[Known Issue]
upload ISO and IMEI will crash the PC. This issue will be resolved at v1.1122.0 version
